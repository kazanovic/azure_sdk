//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_frame_reader_handle_is_valid(AZAC_HANDLE reader);
AZAC_API vision_frame_reader_handle_release(AZAC_HANDLE reader);

AZAC_API vision_frame_reader_properties_handle_get(AZAC_HANDLE reader, AZAC_HANDLE* properties);

AZAC_API vision_frame_reader_read_frame(AZAC_HANDLE reader, uint64_t pos, int stream, AZAC_HANDLE* frame);
// read method ...
