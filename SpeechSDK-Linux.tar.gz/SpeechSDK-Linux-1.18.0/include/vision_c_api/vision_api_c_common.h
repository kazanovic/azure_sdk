//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <stdbool.h>
#include <azac_error.h>
#include <azac_c_common.h>
