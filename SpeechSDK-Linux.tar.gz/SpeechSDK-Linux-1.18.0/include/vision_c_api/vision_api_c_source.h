//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_c_common.h>

AZAC_API_(bool) vision_source_handle_is_valid(AZAC_HANDLE source);
AZAC_API vision_source_handle_create(AZAC_HANDLE* source, const char* optionName, const char* optionValue, AZAC_HANDLE extra);
AZAC_API vision_source_handle_release(AZAC_HANDLE source);

AZAC_API vision_source_properties_handle_get(AZAC_HANDLE source, AZAC_HANDLE* properties);
