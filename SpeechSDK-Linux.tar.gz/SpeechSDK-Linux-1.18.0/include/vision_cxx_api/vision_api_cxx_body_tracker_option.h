//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Options {

enum class BodyTrackerOption
{
    EventHubConnectionString = 1,
    EventHubNamespace = 2,
};

} } } } } // Azure::AI::Vision::Body::Options

PRIVATE_PROPERTY_COLLECTION_STATICS(Azure::AI::Vision::Body::Options::BodyTrackerOption, "body.tracker")
