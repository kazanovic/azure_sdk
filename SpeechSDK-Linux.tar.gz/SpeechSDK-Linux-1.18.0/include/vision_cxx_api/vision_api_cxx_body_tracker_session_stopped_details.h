//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_session_stopped_details.h>
#include <vision_api_cxx_body_tracker_result.h>
#include <vision_api_cxx_body_tracker_session_stopped_reason.h>
#include <vision_api_cxx_body_tracker_session_stopped_event_args.h>
#include <vision_api_cxx_body_tracker_session_stopped_error_reason.h>
#include <vision_api_cxx_properties.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

using namespace Azure::AI::Vision::Body::Events;

/// <summary>
/// Class with additional information about why a Body Tracking session had an error
/// </summary>
class BodyTrackerSessionStoppedDetails :
    private Core::Details::SessionStoppedDetails<BodyTrackingSessionStoppedReason, BodyTrackerSessionStoppedDetails, BodyTrackerResult>
{
private:

    using BaseDetails = Core::Details::SessionStoppedDetails<BodyTrackingSessionStoppedReason, BodyTrackerSessionStoppedDetails, BodyTrackerResult>;

public:

    /// <summary>
    /// Creates an instance of BodyTrackerSessionStoppedDetails object from the BodyTrackerResult.
    /// </summary>
    /// <param name="args">The arguments from a session that stopped for an error.</param>
    /// <returns>A shared pointer to BodyTrackerSessionStoppedDetails.</returns>
    static std::shared_ptr<BodyTrackerSessionStoppedDetails> FromResult(std::shared_ptr<BodyTrackerResult> result)
    {
        return BaseDetails::FromResult(result);
    }

    /// <summary>
    /// Gets the reason for the error
    /// </summary>
    /// <remarks>See BodyTrackingSessionStoppedReason for a list of reasons</remarks>
    /// <returns></returns>
    BodyTrackingSessionStoppedReason GetReason() { return BaseDetails::GetReason(); }

protected:
    static std::shared_ptr<BodyTrackerSessionStoppedDetails> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackerSessionStoppedDetails(handle);
        return std::shared_ptr<BodyTrackerSessionStoppedDetails>(ptr);
    }

    explicit BodyTrackerSessionStoppedDetails(AZAC_HANDLE propertiesHandle)
        : BaseDetails(propertiesHandle) {}
    
    explicit operator AZAC_HANDLE() { return Core::Details::ProtectedAccess<BodyTrackerSessionStoppedDetails>::HandleFromPtr(this); }
            
private:
    DISABLE_DEFAULT_CTORS(BodyTrackerSessionStoppedDetails);
};

}}}}}
