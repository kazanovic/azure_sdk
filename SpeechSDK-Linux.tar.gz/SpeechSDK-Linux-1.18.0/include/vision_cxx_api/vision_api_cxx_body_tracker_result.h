//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <exception>
#include <memory>
#include <string>
#include <vector>

#include <vision_api_cxx_common.h>
#include <vision_api_cxx_details_result_base.h>
#include <vision_api_cxx_body_tracker_result_property.h>
#include <vision_api_cxx_body_tracker_result_reason.h>
#include <vision_api_cxx_body_tracker_result_types.h>
#include <vision_api_cxx_json.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

/// <summary>
/// Represents the output an AI inferencing operation (e.g. detection, recognition, prediction, ...).
/// </summary>
class BodyTrackerResult : private Core::Details::ResultBase<BodyTrackerResultReason, BodyTrackerResultProperty>
{
private:

    using BaseResult = ResultBase<BodyTrackerResultReason, BodyTrackerResultProperty>;

public:

    /// <summary>
    /// Destructs an instance of the BodyTrackerResult class.
    /// </summary>
    ~BodyTrackerResult() = default;

    /// <summary>
    /// Gets the unique id for the Session from which this BodyTrackerResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    std::string GetSessionId() const { return BaseResult::GetSessionId(); }

    /// <summary>
    /// Gets the unique id for the Session from which this BodyTrackerResult originated.
    /// </summary>
    /// <returns>
    /// The Session Id string.
    /// </returns>
    template<class T = std::string>
    Core::Details::enable_if_w_or_string_t<T> GetSessionId() const { return BaseResult::GetSessionId<T>(); }

    /// <summary>
    /// Gets the unique BodyTrackerResult ID for this BodyTrackerResult.
    /// </summary>
    /// <returns>
    /// The unique BodyTrackerResult Id string.
    /// </returns>
    std::string GetResultId() const { return BaseResult::GetResultId(); }

    /// <summary>
    /// Gets the unique BodyTrackerResult ID for this BodyTrackerResult.
    /// </summary>
    /// <returns>
    /// The unique BodyTrackerResult Id string.
    /// </returns>
    template<class T = std::string>
    Core::Details::enable_if_w_or_string_t<T> GetResultId() const { return BaseResult::GetResultId<T>(); }

    /// <summary>
    /// Gets the BodyTrackerResultReason for generation of this result.
    /// </summary>
    BodyTrackerResultReason GetReason() const { return BaseResult::GetReason(BodyTrackerResultReason::NoMatch, BodyTrackerResultReason::Recognized); }

    /// <summary>
    /// Gets the list of Bodies for this result
    /// </summary>
    std::vector<Body> GetBodies() const
    {
        std::vector<Body> bodies;

        auto insightsJson = Properties.Get("insightsJson");

        auto insightsParser = Core::Json::JsonValue::Parse(insightsJson.c_str(), insightsJson.size());
        auto insightJson = insightsParser["insight_list"][0]["insight_json"].AsString();

        auto btParser = Core::Json::JsonValue::Parse(insightJson.c_str(), insightJson.size());

        auto detections = btParser["detections"];
        for (int i = 0; i < detections.Count(); i++)
        {
            auto detection = detections[i];
            if (detection["type"].AsString() != "person")
            {
                continue;
            }

            Body body {};
            body.Id = std::stoul(detection["metadata"]["trackingId"].AsString());

            auto joints = detection["region"]["jointlist"]["joints"];
            if (joints.Count() != Skeleton::JointCount)
            {
                throw std::runtime_error("BodyTracking result does not have the correct number of joints");
            }

            for (int j = 0; j < Skeleton::JointCount; j++)
            {
                auto joint = joints[j];
                auto& outputJoint = body.Skeleton.Joints[j];
                outputJoint.ConfidenceLevel = static_cast<Results::JointConfidenceLevel>(joint["confidence"].AsInt());

                auto point = joint["point"];
                outputJoint.Position.XYZ.X = point["x"].AsFloat();
                outputJoint.Position.XYZ.Y = point["y"].AsFloat();
                outputJoint.Position.XYZ.Z = point["z"].AsFloat();

                auto orientation = joint["orientation"];
                outputJoint.Orientation.WXYZ.W = orientation["w"].AsFloat();
                outputJoint.Orientation.WXYZ.X = orientation["x"].AsFloat();
                outputJoint.Orientation.WXYZ.Y = orientation["y"].AsFloat();
                outputJoint.Orientation.WXYZ.Z = orientation["z"].AsFloat();
            }

            bodies.push_back(body);
        }

        return bodies;
    }

    /// <summary>
    /// Gets a collection of additional inferencing operation properties.
    /// </summary>
    const Core::PropertyCollection<Results::BodyTrackerResultProperty>& Properties;

protected:

    static std::shared_ptr<BodyTrackerResult> FromHandle(AZAC_HANDLE handle)
    {
        auto ptr = new BodyTrackerResult(handle);
        return std::shared_ptr<BodyTrackerResult>(ptr);
    }

    explicit BodyTrackerResult(AZAC_HANDLE result) :
        ResultBase(result),
        Properties(GetProperties())
    {
    }

    explicit operator AZAC_HANDLE() { return Core::Details::ProtectedAccess<BaseResult>::HandleFromPtr(this); }

private:

    DISABLE_DEFAULT_CTORS(BodyTrackerResult);
};

} } } } } // Azure::AI::Vision::Body::Results
