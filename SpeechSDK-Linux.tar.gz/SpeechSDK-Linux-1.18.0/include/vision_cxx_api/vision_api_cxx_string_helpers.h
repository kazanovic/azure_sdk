//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <codecvt>
#include <locale>
#include <type_traits>
#include <string>

#include <vision_api_cxx_common.h>
#include <vision_api_cxx_enums.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {

namespace Details {

template <typename T>
using enable_if_string_t = typename std::enable_if_t<std::is_same<T, std::string>::value, std::string>;

template <typename T>
using enable_if_wstring_t = typename std::enable_if_t<std::is_same<T, std::wstring>::value, std::wstring>;

template <typename T>
using enable_if_w_or_string_t = typename std::enable_if_t<std::is_same<T, std::string>::value || std::is_same<T, std::wstring>::value, T>;

template<typename T1, typename T2 = std::string>
inline enable_if_string_t<T1> to_string(const enable_if_string_t<T2>& value)
{
    return value;
}

template<typename T1, typename T2 = std::wstring>
inline enable_if_wstring_t<T1> to_string(const enable_if_wstring_t<T2>& value)
{
    return value;
}

template<typename T1, typename T2 = std::wstring>
inline enable_if_string_t<T1> to_string(const enable_if_wstring_t<T2>& value)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>, wchar_t> converter;
    return converter.to_bytes(value);
}

template<typename T1, typename T2 = std::string>
inline enable_if_wstring_t<T1> to_string(const enable_if_string_t<T2>& value)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>, wchar_t> converter;
    return converter.from_bytes(value);
}

} // Details

} } } } // Azure::AI::Vision::Core
