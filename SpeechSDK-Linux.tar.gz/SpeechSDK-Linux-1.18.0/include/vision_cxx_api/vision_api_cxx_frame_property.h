//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_properties.h>

#include <vision_api_c_frame_format.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

enum class FrameProperty
{
    TODO = -1

    // TODO: What FrameFormatProperty's do we want?
};

}}}}}
