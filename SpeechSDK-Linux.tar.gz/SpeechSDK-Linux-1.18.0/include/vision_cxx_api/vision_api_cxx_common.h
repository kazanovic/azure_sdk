//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once

#include <azac_debug.h>
#include <vision_api_c_errors.h>

#include <spxdebug.h> // TODO: fully re-factor/duplicate/whatever <spxdebug.h> to have vision sdk not rely directly on public headers from speech sdk
#include <speechapi_cxx_common.h> // TODO: fully re-factor/duplicate/whatever <speechapi_cxx_common.h> to have vision sdk not rely directly on public headers from speech sdk

#include <stdarg.h>
#include <vision_api_cxx_properties.h>
#include <vision_api_cxx_string_helpers.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Core {
namespace Details {

template <class T>
class ProtectedAccess : public T
{
public:

    static AZAC_HANDLE HandleFromPtr(T* ptr) {
        AZAC_IFTRUE_RETURN_X(ptr == nullptr, nullptr);
        auto access = static_cast<ProtectedAccess*>(ptr);
        return (AZAC_HANDLE)(*access);
    }

    static AZAC_HANDLE HandleFromConstPtr(const T* ptr) {
        AZAC_IFTRUE_RETURN_X(ptr == nullptr, nullptr);
        auto access = static_cast<const ProtectedAccess*>(ptr);
        return (AZAC_HANDLE)(*access);
    }

    static std::shared_ptr<T> FromHandle(AZAC_HANDLE handle) {
        return T::FromHandle(handle);
    }

    template<typename... Args>
    static std::shared_ptr<T> Create(Args&&... args) {
        return T::Create(std::forward<Args&&>(args)...);
    }

};

} } } } } // Azure::AI::Vision::Core::Details

