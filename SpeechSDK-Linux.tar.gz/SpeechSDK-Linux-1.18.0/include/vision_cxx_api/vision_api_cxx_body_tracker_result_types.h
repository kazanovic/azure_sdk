//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <array>

namespace Azure {
namespace AI {
namespace Vision {
namespace Body {
namespace Results {

enum JointConfidenceLevel
{
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
};

enum JointId {
    Pelvis = 0,
    SpineNavel = 1,
    SpineChest = 2,
    Neck = 3,
    ClavicleLeft = 4,
    ShoulderLeft = 5,
    ElbowLeft = 6,
    WristLeft = 7,
    HandLeft = 8,
    HandTipLeft = 9,
    ThumbLeft = 10,
    ClavicleRight = 11,
    ShoulderRight = 12,
    ElbowRight = 13,
    WristRight = 14,
    HandRight = 15,
    HandTipRight = 16,
    ThumbRight = 17,
    HipLeft = 18,
    KneeLeft = 19,
    AnkleLeft = 20,
    FootLeft = 21,
    HipRight = 22,
    KneeRight = 23,
    AnkleRight = 24,
    FootRight = 25,
    Head = 26,
    Nose = 27,
    EyeLeft = 28,
    EarLeft = 29,
    EyeRight = 30,
    EarRight = 31
};

union Vector3
{
    // XYZ or array representation of vector
    struct _xyz
    {
        float X;
        float Y;
        float Z;
    } XYZ;       // < X, Y, Z representation of a vector
    float V[3];  // < Array representation of a vector
};

typedef union
{
    // WXYZ or array representation of quaternion
    struct _wxyz
    {
        float W;
        float X;
        float Y;
        float Z;
    } WXYZ;      // < W, X, Y, Z representation of a quaternion
    float V[4];  // < Array representation of a quaternion
} Quaternion;

struct Joint
{
    Vector3 Position;
    Quaternion Orientation;
    JointConfidenceLevel ConfidenceLevel;
};

struct Skeleton
{
    static constexpr int JointCount = 32;
    std::array<Joint, JointCount> Joints;
};

struct Body
{
    uint32_t Id;
    Results::Skeleton Skeleton;
};


} } } } } // Azure::AI::Vision::Body::Results
