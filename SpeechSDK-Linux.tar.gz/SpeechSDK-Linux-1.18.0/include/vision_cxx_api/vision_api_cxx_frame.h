//
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/azai/vision/license202012 for the full license information.
//

#pragma once
#include <vision_api_cxx_common.h>
#include <vision_api_cxx_properties.h>
#include <vision_api_cxx_frame_property.h>

#include <vision_api_c_frame_format.h>

namespace Azure {
namespace AI {
namespace Vision {
namespace Input {
namespace Frames {

/// <summary>
/// Represents a frame
/// </summary>
class Frame
{
protected:
    Core::Details::PrivatePropertyCollection<FrameProperty> m_properties;

public:
    static std::shared_ptr<Frame> Create(const uint8_t* data, size_t dataSizeInBytes)
    {
        auto ptr = new Frame(data, dataSizeInBytes);
        return std::shared_ptr<Frame>(ptr);
    }

    /// <summary>
    /// Gets a collection of additional Frame properties.
    /// </summary>
    Core::PropertyCollection<FrameProperty>& Properties;

    const uint8_t* Data;
    const size_t DataSizeInBytes;

protected:
    explicit Frame(const uint8_t* data, size_t dataSizeInBytes) :
        m_properties(nullptr, [](auto handle, auto* properties) { UNUSED(handle);  return ai_core_properties_handle_create(properties); }),
        Properties(m_properties),
        Data(data),
        DataSizeInBytes(dataSizeInBytes)
    {
    }

    explicit operator AZAC_HANDLE() { return (AZAC_HANDLE)Core::Details::ProtectedAccess<Core::Details::PrivatePropertyCollection<FrameProperty>>::HandleFromPtr(&m_properties); }

};

}}}}}
